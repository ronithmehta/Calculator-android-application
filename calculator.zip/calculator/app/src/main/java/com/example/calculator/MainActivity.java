package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.calculator.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView textViewResult;

    private StringBuilder numberBuilder;
    private double operand1;
    private double operand2;
    private String operator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.textViewResult);
        numberBuilder = new StringBuilder();


        setClickListeners(R.id.buttonone, R.id.buttontwo, R.id.buttonthree, R.id.buttonPlus, R.id.buttonEquals,R.id.buttonClear,R.id.buttonfour,R.id.buttonfive,R.id.buttonsix,R.id.buttonseven,R.id.buttoneight
                ,R.id.buttonnine,R.id.buttonzero,R.id.buttonSub,R.id.buttonDivide,R.id.buttonMultiply);
    }

    private void setClickListeners(int... buttonIds) {
        for (int buttonId : buttonIds) {
            Button button = findViewById(buttonId);
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();
        if (viewId == R.id.buttonone ||
                viewId == R.id.buttontwo ||
                viewId == R.id.buttonthree ||
                viewId == R.id.buttonfour ||
                viewId == R.id.buttonfive ||
                viewId == R.id.buttonsix ||
                viewId == R.id.buttonseven ||
                viewId == R.id.buttoneight ||
                viewId == R.id.buttonnine ||
                viewId == R.id.buttonzero) {
            Button numberButton = (Button) v;
            numberBuilder.append(numberButton.getText().toString());
            textViewResult.setText(numberBuilder.toString());
        } else if (viewId == R.id.buttonPlus) {
            operand1 = Double.parseDouble(numberBuilder.toString());
            operator = "+";
            numberBuilder.setLength(0);
        } else if (viewId == R.id.buttonSub) {
            operand1 = Double.parseDouble(numberBuilder.toString());
            operator = "-";
            numberBuilder.setLength(0);
        } else if (viewId == R.id.buttonMultiply) {
            operand1 = Double.parseDouble(numberBuilder.toString());
            operator = "*";
            numberBuilder.setLength(0);
        } else if (viewId == R.id.buttonDivide) {
            operand1 = Double.parseDouble(numberBuilder.toString());
            operator = "/";
            numberBuilder.setLength(0);
        } else if (viewId == R.id.buttonEquals) {
            if (numberBuilder.length() > 0) {
                operand2 = Double.parseDouble(numberBuilder.toString());
                double result = performCalculation(operand1, operand2, operator);
                textViewResult.setText(String.valueOf(result));
                numberBuilder.setLength(0);
            }

            }
        else if (viewId == R.id.buttonClear) {
            numberBuilder.setLength(0);
            textViewResult.setText("");
        }

    }

    private double performCalculation(double operand1, double operand2, String operator) {
        double result = 0;
        switch (operator) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {

                }
                break;
        }
        return result;
    }
}

